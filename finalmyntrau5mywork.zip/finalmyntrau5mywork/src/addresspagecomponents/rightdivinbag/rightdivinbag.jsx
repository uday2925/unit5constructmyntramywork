
import { Cartproductsinbag } from "../leftdivinbagpage/cartproductsinaddresspage/cartproductsinbagpage"
import { Totalprice } from "./totalpricecard/totalprice"



export const Rightdivinbag=()=>{
    

    return(
        <div>
            <div style={{marginTop:"3%"}}>            
            <Cartproductsinbag/>
            
            </div>            
        </div>
    )
}