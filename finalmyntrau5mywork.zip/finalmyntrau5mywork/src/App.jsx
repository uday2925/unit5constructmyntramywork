import './App.css';

import { Navbar } from './components/navbarfinal/Paymentnavbar';

import { Routesfinal} from "./Routesfinal"


function App() {
  return (
    <div className="App">
      <Navbar/> 
      <Routesfinal/>   
    </div>
  );
}

export default App;
